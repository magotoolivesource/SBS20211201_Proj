using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class LineTimer : MonoBehaviour
{
    void Start()
    {

    }



    public GameObject SecCube;
    public GameObject MinCube;
    public GameObject HourCube;
    int m_CurrentSec = 3675;
    void Timer()
    {
        //int currsec;// = Environment.TickCount;

        m_CurrentSec++;
        int sec = m_CurrentSec % 60; // �ʱ��ϱ� 15
        int min = (m_CurrentSec / 60) % 60; // �� ���ϱ� 
        int hour = m_CurrentSec / (60 * 60); // �ð� ���ϱ�

        // ����ġ
        Vector3 pos = SecCube.transform.position;
        pos.x = sec;
        SecCube.transform.position = pos;

        // ��
        pos = MinCube.transform.position;
        pos.x = min;
        MinCube.transform.position = pos;

        // ��
        pos = HourCube.transform.position;
        pos.x = hour;
        HourCube.transform.position = pos;

    }


    //public GameObject SecCube;

    public int DelaySec = 1000;
    int NextMiliesecCount = 0;
    void DelayCallFN()
    {
        if (Environment.TickCount >= NextMiliesecCount)
        {
            NextMiliesecCount = Environment.TickCount + DelaySec;

            Timer();

            // �̵�
            //MoveCube();
        }
    }

    void Update()
    {
        DelayCallFN();

        //DateTime.Now.Ticks * 100000000
        // 1�ʿ� �ѹ��� ȣ���ϱ�
        
        
    }
}
