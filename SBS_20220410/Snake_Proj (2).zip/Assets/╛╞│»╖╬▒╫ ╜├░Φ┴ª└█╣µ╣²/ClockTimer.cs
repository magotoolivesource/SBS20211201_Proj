using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClockTimer : MonoBehaviour
{
    
    public GameObject HourCenter;
    public GameObject MinCenter;
    public GameObject SecCenter;

    int m_CurrentSec = 3675;

    void ClockTimerUpdate()
    {
        ++m_CurrentSec;
        int sec = m_CurrentSec % 60; // �ʱ��ϱ� 15
        int min = (m_CurrentSec / 60) % 60; // �� ���ϱ� 
        int hour = (m_CurrentSec / (60 * 60)) % 24 ; // �ð� ���ϱ�

        // ȸ�����        
        SecCenter.transform.rotation = Quaternion.Euler(0, sec * 6, 0);
        MinCenter.transform.rotation = Quaternion.Euler(0, min * 6, 0);
        HourCenter.transform.rotation = Quaternion.Euler(0, hour * 15, 0);
    }

    public int DelaySec = 1000;
    int NextMiliesecCount = 0;
    void DelayCallFN()
    {
        

        if (Environment.TickCount >= NextMiliesecCount)
        {
            NextMiliesecCount = Environment.TickCount + DelaySec;

            ClockTimerUpdate();
        }
    }

    void Start()
    {
        
    }

    
    void Update()
    {
        DelayCallFN();

    }
}
