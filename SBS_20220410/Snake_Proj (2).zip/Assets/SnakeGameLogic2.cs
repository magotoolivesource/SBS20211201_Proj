using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SnakeGameLogic2 : MonoBehaviour
{

    public GameObject MyCube;
    public GameObject ItemCube;

    public List<GameObject> SnakeCubeList;

    public List<Vector3> SnakePosArray;


    void CreateSnakeCubeList()
    {
        // ����Ƽ������ ����ϴ� ����� C++, C#������ �ٸ� ���
        GameObject copycube = GameObject.Instantiate(MyCube);
        copycube.name = $"����_{SnakeCubeList.Count}";
        SnakeCubeList.Add(copycube);
    }
    void CreateSnakePos()
    {
        Vector3 pos = new Vector3();
        SnakePosArray.Add( pos );

        CreateSnakeCubeList();
    }

    public Vector3 ItemPos = new Vector3();
    List<int> Pos2ByIndex = new List<int>();
    void RandomItem()
    {
        //System.Random rand = new System.Random();
        //rand.Next(2, 10);



        //ItemPos.x = UnityEngine.Random.Range(-9, 10);
        //ItemPos.z = UnityEngine.Random.Range(-9, 10);
        //ItemPos.y = 0;
        //ItemCube.transform.position = ItemPos;


        Pos2ByIndex.Clear();
        // SnakePosArray
        for (int x = 0; x < 20; x++)
        {
            for (int y = 0; y < 20; y++)
            {
                Pos2ByIndex.Add( x + (y * 20) );
            }
        }

        for (int i = 0; i < SnakePosArray.Count; i++)
        {
            int val = (int)SnakePosArray[i].x 
                        + ((int)SnakePosArray[i].z * 20);
            Pos2ByIndex.Remove(val);
        }

        int randval = UnityEngine.Random.Range(0, Pos2ByIndex.Count);
        int outval = Pos2ByIndex[randval];

        ItemPos.z = (outval / 20);
        ItemPos.x = (outval % 20);


        ItemCube.transform.position = ItemPos;
    }

    void Start()
    {
        for (int i = 0; i < 100; i++)
        {
            CreateSnakePos();
        }
        

        RandomItem();
    }



    public int DelaySec = 1000;
    int NextMiliesecCount = 0;
    void DelayCallFN()
    {
        if (Environment.TickCount >= NextMiliesecCount)
        {
            NextMiliesecCount = Environment.TickCount + DelaySec;

            // �̵�
            MoveSnake();

            CollisionBodyCheck();
            CollisionItemCheck();
        }
    }

    bool CollisionBodyCheck()
    {
        if( SnakePosArray[0].x <= -10
            || SnakePosArray[0].x >= 10
            || SnakePosArray[0].z >= 10
            || SnakePosArray[0].z <= -10
            )
            return true;


        //Vector3 headpos = 
        for (int i = 1; i < SnakePosArray.Count; i++)
        {
            if( SnakePosArray[0].x == SnakePosArray[i].x
                && SnakePosArray[0].z == SnakePosArray[i].z)
            {
                Debug.Log("���ӿ���");
                return true;
            }
        }
        return false;
    }

    void CollisionItemCheck()
    {
        if( ItemPos.x == SnakePosArray[0].x
            && ItemPos.z == SnakePosArray[0].z )
        {
            CreateSnakePos();

            // ��ġ�ٽý���
            SnakePosArray[SnakePosArray.Count - 1] = LastPos;
            SnakeCubeList[SnakePosArray.Count - 1].transform.position = LastPos;

            // ������ �浹��
            RandomItem();

            if( SnakePosArray.Count % 3 == 0)
                DelaySec -= 50;

            if(DelaySec <= 50)
                DelaySec = 50;
        }

    }

    public E_Direction Direction = E_Direction.Left; // 0 ������, 1 ����, 2 ��, 3 �Ʒ�
    public Vector3 LastPos = new Vector3();
    void MoveSnake()
    {
        // �迭�� �ڿ������� 0������ �̵��ؼ� ��ġ�� �����ϱ�
        int count = SnakePosArray.Count;
        LastPos = SnakePosArray[count -1];
        for (int i = count - 1; i >= 1; i--)
        {
            SnakePosArray[i] = SnakePosArray[i - 1];
        }


        Vector3 headpos = SnakePosArray[0];

        switch (Direction)
        {
            case E_Direction.Right:
                headpos.x += 1;
                break;
            case E_Direction.Left:
                headpos.x -= 1;
                break;
            case E_Direction.Up:
                headpos.z += 1;
                break;
            case E_Direction.Down:
                headpos.z -= 1;
                break;

            default:
                break;
        }

        SnakePosArray[0] = headpos;


        //int size = SnakePosArray.Count;
        for (int i = 0; i < count; i++)
        {
            SnakeCubeList[i].transform.position = SnakePosArray[i];
        }
    }


    void UpdateInputKeyboard()
    {
        // c++ , c# ,

        // Unity ������ ���Ǵ� ���ɾ���
        if (Input.GetKey(KeyCode.RightArrow)
            || Input.GetKey(KeyCode.D))
        {
            Direction = E_Direction.Right;
        }

        if (Input.GetKey(KeyCode.LeftArrow)
            || Input.GetKey(KeyCode.A))
        {
            Direction = E_Direction.Left;
        }

        if (Input.GetKey(KeyCode.UpArrow)
            || Input.GetKey(KeyCode.W))
        {
            Direction = E_Direction.Up;
        }

        if (Input.GetKey(KeyCode.DownArrow)
            || Input.GetKey(KeyCode.S))
        {
            Direction = E_Direction.Down;
        }
    }

    void Update()
    {
        UpdateInputKeyboard();

        DelayCallFN();


    }
}
