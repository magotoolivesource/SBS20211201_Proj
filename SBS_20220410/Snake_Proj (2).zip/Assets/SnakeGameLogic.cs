using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public enum E_Direction
{
    Right = 0,
    Left,
    Up,
    Down
}

//public class POINT2
//{
//    public int x;
//    public int y;
//}


public class SnakeGameLogic : MonoBehaviour
{
    public GameObject MyCube;
    public Vector3[] SnakePosArray;


    public List<GameObject> SnakeCubeList;
    void CreateSnakeCubeList()
    {
        // ����Ƽ������ ����ϴ� ����� C++, C#������ �ٸ� ���
        GameObject copycube = GameObject.Instantiate(MyCube);
        copycube.name = $"����_{SnakeCubeList.Count}";
        SnakeCubeList.Add(copycube);
    }
    public GameObject[] SnakeCube;
    void CreateSnakeCube()
    {
        // ����Ƽ������ ����ϴ� ����� C++, C#������ �ٸ� ���
        GameObject copycube = GameObject.Instantiate(MyCube);
        copycube.name = $"����_{SnakeCube.Length}";
        // �ӽ� ����ҿ� cube �迭 �����α�
        GameObject[] tempcubearr = new GameObject[SnakeCube.Length + 1];
        for (int i = 0; i < SnakeCube.Length; i++)
        {
            tempcubearr[i] = SnakeCube[i];
        }

        SnakeCube = tempcubearr;
        SnakeCube[SnakeCube.Length - 1] = copycube;
    }

    void CreateSnakePos()
    {

    }

    void Init()
    {
        SnakePosArray = new Vector3[5];

        SnakePosArray[0] = new Vector3(-1, 0, 0);
        SnakePosArray[1] = new Vector3(0, 0, 0);


        //CreateSnakeCube();
        //CreateSnakeCube();
        //CreateSnakeCube();
        //CreateSnakeCube();
        //CreateSnakeCube();

        CreateSnakeCubeList();
        CreateSnakeCubeList();
        CreateSnakeCubeList();
        CreateSnakeCubeList();
        CreateSnakeCubeList();
    }

    void Start()
    {
        Init();


        //Vector3 pos = MyCube.transform.position;
        //pos.x = 20;
        //MyCube.transform.position = pos;

        ////MyCube.transform.position.x =20;
        //float xx = MyCube.transform.position.x;
        ////SecCube.transform.position.Set(10, 20, 30);


    }



    //public GameObject SecCube;

    public int DelaySec = 1000;
    int NextMiliesecCount = 0;
    void DelayCallFN()
    {
        if (Environment.TickCount >= NextMiliesecCount)
        {
            NextMiliesecCount = Environment.TickCount + DelaySec;

            // �̵�
            //MoveCube();
            MoveSnake();
        }
    }


    public E_Direction Direction = E_Direction.Left; // 0 ������, 1 ����, 2 ��, 3 �Ʒ�

    void MoveSnake()
    {
        // �迭�� �ڿ������� 0������ �̵��ؼ� ��ġ�� �����ϱ�
        int count = SnakePosArray.Length;
        for (int i = count - 1; i >= 1; i--)
        {
            SnakePosArray[i] = SnakePosArray[i - 1];
        }

        Vector3 headpos = SnakePosArray[0];

        switch (Direction)
        {
            case E_Direction.Right:
                headpos.x += 1;
                break;
            case E_Direction.Left:
                headpos.x -= 1;
                break;
            case E_Direction.Up:
                headpos.z += 1;
                break;
            case E_Direction.Down:
                headpos.z -= 1;
                break;

            default:
                break;
        }

        SnakePosArray[0] = headpos;

        
        int size = SnakePosArray.Length;
        for (int i = 0; i < size; i++)
        {
            //SnakeCube[i].transform.position = SnakePosArray[i];
            SnakeCubeList[i].transform.position = SnakePosArray[i];
        }
        
    }

    void MoveCube()
    {


        Vector3 currpos = MyCube.transform.position;

        switch (Direction)
        {
            case E_Direction.Right:
                currpos.x += 1;
                break;
            case E_Direction.Left:
                currpos.x -= 1;
                break;
            case E_Direction.Up:
                currpos.z += 1;
                break;
            case E_Direction.Down:
                currpos.z -= 1;
                break;

            default:
                break;
        }
        
        MyCube.transform.position = currpos;
    }


    void UpdateInputKeyboard()
    {
        // c++ , c# , Unity 
        if( Input.GetKey(KeyCode.RightArrow)
            || Input.GetKey(KeyCode.D) )
        {
            Direction = E_Direction.Right;
        }

        if (Input.GetKey(KeyCode.LeftArrow)
            || Input.GetKey(KeyCode.A))
        {
            Direction = E_Direction.Left;
        }

        if (Input.GetKey(KeyCode.UpArrow)
            || Input.GetKey(KeyCode.W))
        {
            Direction = E_Direction.Up;
        }

        if (Input.GetKey(KeyCode.DownArrow)
            || Input.GetKey(KeyCode.S))
        {
            Direction = E_Direction.Down;
        }
    }

    void Update()
    {
        UpdateInputKeyboard();

        DelayCallFN();
        
    }
}
