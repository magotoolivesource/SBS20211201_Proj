using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestList : MonoBehaviour
{

    public GameObject[] SnakeCube;
    public List<GameObject> SnakeCubeList;

    void Start()
    {
        //SnakeCube = new GameObject[10]; // ������ �˷��������
        //SnakeCube[0];
        //SnakeCube.Length;
        //SnakeCube = null;




        //SnakeCubeList = new List<GameObject>(); // ����� �˸� �ʿ䰡 ����
        //SnakeCubeList.Add(null);
        //SnakeCubeList.Add(null);
        //SnakeCubeList.Count; // 2��
        //SnakeCubeList.Add(null);
        //SnakeCubeList.Count; // 3��

        //SnakeCubeList.RemoveAt(2);
        //SnakeCubeList.Clear();



        //SnakeCubeList[0] = null;

    }

    void Update()
    {
        
    }
}
