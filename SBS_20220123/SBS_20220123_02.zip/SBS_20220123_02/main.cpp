#define _CRT_SECURE_NO_WARNINGS

#include "stdlib.h"
#include "stdio.h"
#include "string.h"




struct MyScoreStruct
{
	int MiddleScore;
	int KoreanScore;
	int HistoryScore;
};
struct StudentInfo
{
	char name[32];
	MyScoreStruct scoreScore;
	int studentid;
	float eyevision;
};
typedef StudentInfo info;
typedef StudentInfo* pinfo;


typedef struct StudentInfo2
{
	char name[32];
	MyScoreStruct scoreScore;
	int studentid;
	float eyevision;
}info2, *pinfo2;

//typedef StudentInfo info;
typedef int int32;


void TestSource()
{
	int studentinfo[35];
	int studentinfo33[35];
	//studentinfo33 = studentinfo;
	studentinfo[0];
	studentinfo[32];
	studentinfo[33];
	studentinfo[34];

	StudentInfo info;
	//info.name = "efg";
	sprintf_s( &info.name[0], 32, "%s", "efg"); // �̸� ���
	info.studentid = 101101;
	info.eyevision = 0.5;
	

	StudentInfo info2;
	info2 = info;
	
	


	//StudentInfo info2[3];
	//info2[0].name;
	//info2[1].name;
	//info2[1].studentid;


	//// �л��鿡 ���õ� �ڷ� ����
	//// �л��̸�, �й�, �÷�;
	//char Aname[32] = "jhon";
	//int AstudentID = 101101;
	//float AEyeVision = 0.7;


	//char Bname[32] = "Jeny";
	//int BstudentID = 101102;
	//float BEyeVision = 1.3;

	//char Cname[32] = "Dog";
	//int CstudentID = 101105;
	//float CEyeVision = 2.7;


	//char studentName[3][32] = { "jhon", "Jeny", "Dog" };
	//char BstudentID[3] = { 101101, 101102, 101105 };
	//char EyeVision[3] = { 0.7, 1.3, 2.7 };



}
void TestSource2_2(StudentInfo* p_info)
{
	info* ptemp = NULL;
	pinfo ptemp2 = NULL;


	info2* ptemp3 = NULL;

	int size = sizeof(p_info);

	p_info->studentid = 100;
	p_info->scoreScore.KoreanScore = 100;

}
void TestSource2_1(StudentInfo p_info)
{
	int size = sizeof(p_info);
	p_info.eyevision = 2.3;
	p_info.scoreScore.MiddleScore = 10;

}

void TestSource2()
{
	StudentInfo info = { 0, };
	StudentInfo info2 = { 0, };
	strcpy_s(info.name, 32, "abc");

	info2 = info;
	//info2.name = info.name;

	info.studentid = 1001;
	info.eyevision = 1.3;

	TestSource2_1(info);
	TestSource2_2( &info );
}


void TestSource3()
{
	StudentInfo info = { 0, };

	printf("�̸��� �Է��ϼ��� : ");
	scanf("%s", info.name);

	printf("�й��� �Է��ϼ��� : ");
	scanf("%d", &info.studentid );


	printf("�̸��� �й��� �Է��ϼ��� : ");
	scanf("%s %d", info.name, &info.studentid);


	
	StudentInfo infos[] = {
		{"abc"
			, {10, 20, 30}
			, 10010
			, 1.2
		}

		, {"abc"
			, {10, 20, 30}
			, 10010
			, 1.2
		}
	};

	StudentInfo* pinfo = &infos[0];
	(*pinfo).studentid = 200;
	pinfo->studentid = 200;
	pinfo[0].studentid = 200;
	pinfo[1].studentid = 201;

	pinfo += 1;
	pinfo[0].studentid = 1200;

	//infos[0].studentid = 1001221;

}

void main()
{
	TestSource3();

	//TestSource2();

	//TestSource();


}



