#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "ctype.h"

void MyStringUpper()
{

}


void TestSource2()
{

	//
	//// A~Z 65~90
	//// a~z 97~122
	//char tempchar[32] = "aBcDe";
	//tempchar[0] = 'z'; // 
	//tempchar[1] = 'A'; // 

	//// �ҹ���
	//if (tempchar[0] >= 97 && tempchar[0] <= 122)
	//{
	//	tempchar[0] = 
	//}

	//MyStringUpper(tempchar);
	////tempchar -> "ABCDE"

	//char srcchar[32] = "Hello";
	//char destchar[32] = " World";
	//char outchar[64] = ""; // Hello World
	//MyConCat();

}

void MyUpperString( char p_str[], int p_strsize )
{
	for (int i = 0; i < p_strsize; i++)
	{
		int tempchar1 = p_str[i];
		if ((97 <= tempchar1
			&& tempchar1 <= 122))
		{
			tempchar1 -= 32;
			p_str[i] = tempchar1;
		}
	}
}

void MyUpperSting2(char p_str[])
{
	for (int i = 0; p_str[i] != '\0'; i++)
	{
	/*	if (p_str[i] == '\0')
			break;*/

		int tempchar1 = p_str[i];
		if ((97 <= p_str[i]
			&& p_str[i] <= 122))
		{
			p_str[i] -= 32;
		}
	}
}

void TestSource3()
{
	//char tempchar[32] = "aBcDe";// -> ABCDE


	// �ѹ��ڸ� �ٲ��ִ� �빮�ڱ��
	//// A~Z 65~90
	//// a~z 97~122
	int tempchar1 = 'b';// 'a';//->A, ->B

	if ( (97 <= tempchar1
		&& tempchar1 <= 122) )
	{
		tempchar1 -= 32;
	}
	
	char tempstr[] = "abEfvnlu Nlunbalkun;lvHaHHnyg{O)K{";// -> ABCDEF
	//for (int i = 0; i < 32; i++)
	//{
	//	int tempchar1 = tempstr[i];
	//	if ((97 <= tempchar1
	//		&& tempchar1 <= 122))
	//	{
	//		tempchar1 -= 32;
	//		tempstr[i] = tempchar1;
	//	}
	//}

	MyUpperSting2(tempstr);

	printf("%s", tempstr);



	//int tempchar1 = tempstr[0];
	//if ((97 <= tempchar1
	//	&& tempchar1 <= 122))
	//{
	//	tempchar1 -= 32;
	//	tempstr[0] = tempchar1;
	//}

	//tempchar1 = tempstr[1];
	//if ((97 <= tempchar1
	//	&& tempchar1 <= 122))
	//{
	//	tempchar1 -= 32;
	//	tempstr[1] = tempchar1;
	//}

	//tempchar1 = tempstr[2];
	//if ((97 <= tempchar1
	//	&& tempchar1 <= 122))
	//{
	//	tempchar1 -= 32;
	//	tempstr[2] = tempchar1;
	//}

	char tempint = '9';
	char tempint2[] = "12345";

	int tempval = 0;
	tempval = (tempval * 10) + (tempint2[0] - '0');
	tempval = (tempval * 10) + (tempint2[1] - '0');
	tempval = (tempval * 10) + (tempint2[2] - '0');
	tempval = (tempval * 10) + (tempint2[3] - '0');
}

void MyConCat( char* p_srcchar, char* p_destchar, char* p_threadchar, char* p_outsting )
{
	int at = 0;
	for (int i = 0; ; i++)
	{
		if (p_srcchar[i] == '\0')
		{
			break;
		}

		p_outsting[at++] = p_srcchar[i];
	}

	for (int i = 0; ; i++)
	{
		if (p_destchar[i] == '\0')
		{
			break;
		}

		p_outsting[at++] = p_destchar[i];
	}

	for (int i = 0; ; i++)
	{
		if (p_threadchar[i] == '\0')
		{
			break;
		}

		p_outsting[at++] = p_threadchar[i];
	}
}
void TestSource4()
{
	char srcchar[32] = "Hac";
	char destchar[32] = " W";
	char outchar[64] = ""; // H W

	int at = 0;

	for (int i = 0; ; i++)
	{
		if (srcchar[i] == '\0')
		{
			break;
		}
			
		outchar[at++] = srcchar[i];
	}
	//outchar[at++] = srcchar[0];
	//outchar[at++] = srcchar[1];
	//outchar[at++] = srcchar[2];
	//outchar[0] = srcchar[0];
	// at =1
	//outchar[1] = srcchar[0];


	for (int i = 0; ; i++)
	{
		if (destchar[i] == '\0')
		{
			break;
		}

		outchar[at++] = destchar[i];
	}
	//outchar[at++] = destchar[0];
	////at++;
	//outchar[at++] = destchar[1];
	////at++;


	outchar[at] = '\0';

	
	printf("%s", outchar);
}

void main()
{

	// ���ڿ� ����� ���� �κ�
	//TestSource4();

	//TestSource3();

	//TestSource2();

	//TestSource1();

}

