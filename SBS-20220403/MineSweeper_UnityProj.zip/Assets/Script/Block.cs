using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{

    public GameManager Manager = null;
    public Material MineImage;
    public Material[] MineBlockMaterials;
    public bool m_ISOpen = false;


    public void DirectOpen()
    {
        m_ISOpen = true;

        if( MineBlockMaterials.Length <= 0 )
            return;

        int x = (int)this.transform.position.x; // 0 ~ 0.999 = 0
        int y = (int)this.transform.position.y;
        int minecount = Manager.GetAroundMineCount(x, y);

        string msg = $"{this.name}  ���� : {minecount}";
        Debug.Log(msg);

        MeshRenderer renderer = this.GetComponent<MeshRenderer>();
        renderer.material = MineBlockMaterials[minecount];
    }

    public void RecusiveDirectOpen()
    {
        if (m_ISOpen)
            return;

        DirectOpen();


        int x = (int)this.transform.position.x;
        int y = (int)this.transform.position.y;
        int minecount = Manager.GetAroundMineCount(x, y);

        if (minecount <= 0)
        {
            if(x + 1 < Manager.BlockSize)
            {
                // ������
                Manager.BlockArray2By[y, x + 1].RecusiveDirectOpen();
            }

            if (x - 1 >= 0)
            {
                // ����
                Manager.BlockArray2By[y, x - 1].RecusiveDirectOpen();
            }

            if (y + 1 < Manager.BlockSize)
            {
                // ����
                Manager.BlockArray2By[y + 1, x].RecusiveDirectOpen();
            }

            if (y - 1 >= 0)
            {
                // �ϴ�
                Manager.BlockArray2By[y - 1, x].RecusiveDirectOpen();
            }

        }


        
        // ũ�ν� ��� ���� �ҽ�
        //if (minecount <= 0)
        //{
        //    for (int xx = x + 1; xx < Manager.BlockSize; xx++)
        //    {
        //        // ������
        //        minecount = Manager.GetAroundMineCount(xx, y);
        //        if (minecount <= 0)
        //        {
        //            Manager.BlockArray2By[y, xx].DirectOpen();
        //        }
        //        else
        //        {
        //            Manager.BlockArray2By[y, xx].DirectOpen();
        //            break;
        //        }
        //    }

        //    // ����
        //    for (int xx = x - 1; xx >= 0; xx--)
        //    {
        //        minecount = Manager.GetAroundMineCount(xx, y);
        //        if (minecount <= 0)
        //        {
        //            Manager.BlockArray2By[y, xx].DirectOpen();
        //        }
        //        else
        //        {
        //            Manager.BlockArray2By[y, xx].DirectOpen();
        //            break;
        //        }
        //    }

        //    // ����
        //    for (int yy = y; yy < Manager.BlockSize; yy++)
        //    {
        //        minecount = Manager.GetAroundMineCount(x, yy);
        //        if (minecount <= 0)
        //        {
        //            Manager.BlockArray2By[yy, x].DirectOpen();
        //        }
        //        else
        //        {
        //            Manager.BlockArray2By[yy, x].DirectOpen();
        //            break;
        //        }
        //    }


        //    // �Ʒ���
        //    for (int yy = y - 1; yy >= 0; yy--)
        //    {
        //        minecount = Manager.GetAroundMineCount(x, yy);
        //        if (minecount <= 0)
        //        {
        //            Manager.BlockArray2By[yy, x].DirectOpen();
        //        }
        //        else
        //        {
        //            Manager.BlockArray2By[yy, x].DirectOpen();
        //            break;
        //        }
        //    }
        //}
    }

    private void OnMouseDown()
    {
        if(m_ISOpen)
        {
            return;
        }

        //DirectOpen();

        RecusiveDirectOpen();


        
    }



    void Start()
    {

        //TestRecusiveFN(0);




        GameManager gamemanager = this.GetComponent<GameManager>();


        //int selectval = 3;

        //MeshRenderer renderer = this.GetComponent<MeshRenderer>();
        //renderer.material = MineBlockMaterials[ selectval ];

        //if (selectval == 0)
        //{
        //    MeshRenderer renderer = this.GetComponent<MeshRenderer>();
        //    renderer.material = MineMateril0;
        //}

        //if( selectval == 1)
        //{
        //    MeshRenderer renderer = this.GetComponent<MeshRenderer>();
        //    renderer.material = MineMateril1;
        //}

        

    }

    
    void Update()
    {
        
    }
}
