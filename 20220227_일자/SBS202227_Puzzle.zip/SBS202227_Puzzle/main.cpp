#pragma warning(disable : 4996)
#include <iostream>
#include "windows.h"
#include "conio.h"


#define PUZZLESIZE 3

void MySetCursorPos(int p_x, int p_y)
{
	COORD dwCursorPosition;
	dwCursorPosition.X = p_x;
	dwCursorPosition.Y = p_y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE)
		, dwCursorPosition);
}

void main()
{
	int puzzlesize = 5;
	int puzzlearr[PUZZLESIZE * PUZZLESIZE] = { 0, };

	// �⺻ ����
	for (int i = 0; i < PUZZLESIZE * PUZZLESIZE; i++)
	{
		puzzlearr[i] = i + 1;
	}
	
	// ȭ�鿡 �����
	for (int j = 0; j < PUZZLESIZE; j++)
	{
		for (int i = 0; i < PUZZLESIZE; i++)
		{
			// Ŀ�� ��ġ
			MySetCursorPos(i * 5, j * 2);

			int at = i + (j * PUZZLESIZE);
			if (puzzlearr[at] == PUZZLESIZE * PUZZLESIZE)
			{
				printf("*    ");
			}
			else
			{

				printf("%d    ", puzzlearr[at]);
			}
			
		}
		printf("\n");
		//printf("\n");
	}
	


	//for (int j = 0; j < puzzlesize; j++)
	//{
	//	int row = j;
	//	for (int i = 0; i < puzzlesize; i++)
	//	{
	//		int val = (i + 1) + (puzzlesize * row);
	//		if (val == puzzlesize * puzzlesize)
	//		{
	//			printf("*   ");
	//		}
	//		else
	//		{
	//			printf("%d   ", val);
	//		}
	//	}
	//	printf("\n");
	//}
	//

	/*for (int i = 0; i < 3; i++)
	{
		printf("%d   ", (i + 1) + (3 * 0));
	}
	printf("\n");


	for (int i = 0; i < 3; i++)
	{
		printf("%d   ", (i + 1) + (3*1) );
	}
	printf("\n");


	for (int i = 0; i < 3; i++)
	{
		printf("%d   ", (i + 1) + (3 * 2));
	}
	printf("\n");*/


}



