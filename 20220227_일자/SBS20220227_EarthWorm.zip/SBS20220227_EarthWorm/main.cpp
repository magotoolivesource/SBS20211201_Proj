#pragma warning(disable : 4996)
#include <iostream>
#include <Windows.h>
#include "conio.h" // c���
//#include <cstdio>


void SetDrawText(int p_x, int p_y, const char* p_val)
{
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD dwCursorPosition;
	dwCursorPosition.X = p_x;
	dwCursorPosition.Y = p_y;
	SetConsoleCursorPosition(hConsoleOutput, dwCursorPosition);

	//printf(p_val);
	std::cout << p_val;
}


void LineDrawEmpty(int p_widht)
{
	// #      #
	for (int i = 0; i < p_widht; i++)
	{
		if (0 == i || p_widht - 1 == i)
		{
			//printf("#");
			std::cout << "#";
		}
		else
		{
			//printf(" ");
			std::cout << " ";
		}
	}
	//printf("\n");
	std::cout << std::endl;
}
void LineDraw(int p_widht)
{
	// ########
	for (int i = 0; i < p_widht; i++)
	{
		//printf("#");
		std::cout << "#";
	}
	//printf("\n");
	std::cout << std::endl;
	
}

void StageWallDraw(int p_widht, int p_height)
{

	for (int j = 0; j < p_height; j++)
	{
		if (0 == j || p_height - 1 == j)
		{
			LineDraw(p_widht);
		}
		else
		{
			LineDrawEmpty(p_widht);
		}
	}
}

void PlayerDraw( int p_x, int p_y )
{
	SetDrawText(p_x, p_y, "@");
}

void main()
{
	int width = 15;
	int height = 8;

	int playerposx = 5;
	int playerposy = 3;

	char keyboardpress = '\0';
	while (true)
	{
		system("cls");
		StageWallDraw(width, height);
		PlayerDraw(playerposx, playerposy);

		
		int keypress = _getch();

		if (keypress == 'a')
		{
			playerposx--;
		}

		if (keypress == 'd')
		{
			playerposx++;
		}

		if (keypress == 'w')
		{
			playerposy--;
		}

		if (keypress == 's')
		{
			playerposy++;
		}

		//scanf("%c", &keyboardpress); // ����Ű �Է� �޾ƾ��� ��밡��
		//std::cin >> keyboardpress;

		Sleep(1000);
	}
	
}
