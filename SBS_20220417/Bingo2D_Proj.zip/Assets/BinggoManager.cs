using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BinggoManager : MonoBehaviour
{
    public BingoLogic[] BinggoLogicArr;

    public void SendEventSelectValue(int p_val)
    {
        foreach (var item in BinggoLogicArr)
        {
            item.SetBinggoVal(p_val);
        }
        
    }


    public int BinggoPanSize = 3;
    public BingoLogic LogicCloneData = null;
    void Start()
    {
        BinggoLogicArr = new BingoLogic[BinggoPanSize];

        for (int i = 0; i < BinggoPanSize; i++)
        {
            BingoLogic logic = GameObject.Instantiate(LogicCloneData);
            logic.gameObject.SetActive(true);
            BinggoLogicArr[i] = logic;
            BinggoLogicArr[i].name = $"������_{i}";
            BinggoLogicArr[i].transform.position = new Vector3(i * 10, 0, 0);
        }

    }

    
    void Update()
    {
        
    }
}
