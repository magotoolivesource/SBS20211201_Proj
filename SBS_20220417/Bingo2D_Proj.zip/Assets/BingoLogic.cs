using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BingoLogic : MonoBehaviour
{
    static System.Random rand = new System.Random();

    public TextMesh BingoMesh;



    int GetValue(int p_val)
    {
        return p_val >= 1000 ? p_val - 1000 : p_val;
    }


    public int BinggoSize = 3;


    protected int[,] TempArr3 = null;
    protected NumberClick[,] NumberClickArr = null;

    void CreateTextMesh()
    {
        NumberClickArr = new NumberClick[BinggoSize, BinggoSize];
        int xsize = TempArr3.GetLength(1);
        int ysize = TempArr3.GetLength(0);

        float tempx = transform.position.x;
        float tempy = transform.position.y;
        for (int y = 0; y < ysize; y++)
        {
            for (int x = 0; x < xsize; x++)
            {
                // ȭ������Һκ�
                TextMesh copyobj = GameObject.Instantiate(BingoMesh);
                copyobj.gameObject.SetActive(true);
                copyobj.transform.position = new Vector3( (x * 2) + tempx
                    , (-y * 2) + tempy
                    , 0f);
                // ��������
                copyobj.text = $"{TempArr3[y, x]}";

                copyobj.GetComponent<NumberClick>().BinggoVal = TempArr3[y, x];
                NumberClickArr[y, x] = copyobj.GetComponent<NumberClick>();
                //copyobj.GetComponent<NumberClick>().ParentLogic = this;
            }
        }

        // ���� hide �ϱ�
        BingoMesh.gameObject.SetActive(false);
    }
    void CreateBinngoSize()
    {
        TempArr3 = new int[BinggoSize, BinggoSize];

        int xsize = TempArr3.GetLength(1);
        int ysize = TempArr3.GetLength(0);

        for (int y = 0; y < ysize; y++)
        {
            for (int x = 0; x < xsize; x++)
            {
                TempArr3[y, x] = (x) + (y * xsize) + 1;
            }
        }

        
        // ����
        for (int y = 0; y < ysize; y++)
        {
            for (int x = 0; x < xsize; x++)
            {
                int swapx = rand.Next(0, BinggoSize); // 0~ BinggoSize
                int swapy = rand.Next(0, BinggoSize); // 0~ BinggoSize

                int tempval = TempArr3[y, x];
                TempArr3[y, x] = TempArr3[swapx, swapy];
                TempArr3[swapx, swapy] = tempval;
            }
        }

        //TestBinggo();

        CreateTextMesh();
    }

    void TestBinggo()
    {
        TempArr3[0, 0] = 2; TempArr3[0, 1] = 7; TempArr3[0, 2] = 4;
        TempArr3[1, 0] = 8; TempArr3[1, 1] = 6; TempArr3[1, 2] = 5;
        TempArr3[2, 0] = 1; TempArr3[2, 1] = 3; TempArr3[2, 2] = 9;

    }

    public int SetBinggoVal( int p_setval )
    {
        for (int y = 0; y < BinggoSize; y++)
        {
            for (int x = 0; x < BinggoSize; x++)
            {
                if( TempArr3[y, x] == p_setval )
                {
                    NumberClickArr[y,x].SetChangeClick();
                    //Debug.Log( $"{x}, {y}��ġ�� �ִ� �� : {TempArr3[y, x]} �ٲ�" );
                    TempArr3[y, x] += 1000;
                }
            }
        }

        // ���� üũ ó�� ����
        CheckBinggo();


        int templinecount = 0;
        foreach (var item in ISCheckLineArr)
        {
            if (item)
            {
                ++templinecount;
            }
        }
        return templinecount;
    }


    bool[] ISCheckLineArr = null;
    void CheckBinggo()
    {
        
        // ���� ����
        for (int x = 0; x < BinggoSize; x++)
        {
            //int xx = x;
            bool isVline = true;
            for (int y = 0; y < BinggoSize; y++)
            {
                if (TempArr3[y, x] < 1000)
                {
                    isVline = false;
                    break;
                }
            }
            if (isVline
                && ISCheckLineArr[x] == false )
            {
                ISCheckLineArr[x] = true;
                Debug.Log($"{gameObject.name}, {x}��° ���� ���� ����:");
            }
        }


        // ���� ����
        for (int y = 0; y < BinggoSize; y++)
        {
            int yy = y;
            bool isline = true;
            for (int x = 0; x < BinggoSize; x++)
            {
                if (TempArr3[yy, x] < 100)
                {
                    isline = false;
                    break;
                }
            }
            // 0��° ���κ���
            if (isline
                && ISCheckLineArr[y + BinggoSize] == false )
            {
                ISCheckLineArr[y + BinggoSize] = true;
                Debug.Log($"{gameObject.name}, {yy}��° ���� ���� ���� ");
            }
        }



        // \
        bool iswline = true;
        for (int i = 0; i < BinggoSize; i++)
        {
            if (TempArr3[i, i] < 1000)
            {
                iswline = false;
                break;
            }
        }

        if (iswline
            && ISCheckLineArr[BinggoSize + BinggoSize] == false )
        {
            ISCheckLineArr[BinggoSize+BinggoSize] = true;
            Debug.Log($"{gameObject.name}, X ���ο� ũ�ν�1 ����");
        }



        // /
        bool iscrossline2 = true;
        for (int i = 0; i < BinggoSize; i++)
        {
            int yy = BinggoSize - i - 1;
            if (TempArr3[yy, i] < 1000)
            {
                iscrossline2 = false;
                break;
            }
        }

        if (iscrossline2
            && ISCheckLineArr[BinggoSize + BinggoSize + 1] == false)
        {
            ISCheckLineArr[BinggoSize + BinggoSize + 1] = true;
            Debug.Log($"{gameObject.name}, X ���ο� ũ�ν�2 ����");
        }
    }


    void Start()
    {
        if( BinggoSize % 2 == 0 )
        {
            BinggoSize += 1;
            Debug.Log($"������ �̻��� ������ �ø� : {BinggoSize}");
        }

        ISCheckLineArr = new bool[ BinggoSize + BinggoSize + 2];
        CreateBinngoSize();



        ////// C++ ���
        ////// int temparr[3];
        ////// 2���� �迭
        ////// int temparr[3][3];

        ////// C#
        ////int[] TempArr = new int[3];
        ////TempArr[2] = 0;

        ////// C# ���� 2���� �迭
        ////int[][] TempArr2 = new int[3][];
        ////for (int i = 0; i < TempArr2.Length; i++)
        ////{
        ////    TempArr2[i] = new int[3];
        ////}

        //// c++ �̷� ����� ����
        //int[,] TempArr3 = new int[BinggoSize, BinggoSize];

        //int xsize = TempArr3.GetLength(1);
        //int ysize = TempArr3.GetLength(0);

        //for (int y = 0; y < ysize; y++)
        //{
        //    for (int x = 0; x < xsize; x++)
        //    {
        //        TempArr3[ y, x ] = (x) + (y * xsize);
        //    }
        //}


        //// �׽�Ʈ����
        //TempArr3[0, 0] = 1001; TempArr3[0, 1] = 100; TempArr3[0, 2] = 1003; TempArr3[0, 3] = 100;
        //TempArr3[1, 0] = 100; TempArr3[1, 1] = 1005; TempArr3[1, 2] = 100; TempArr3[1, 3] = 100;
        //TempArr3[2, 0] = 1007; TempArr3[2, 1] = 1002; TempArr3[2, 2] = 1009;


        //int val = TempArr3[0, 0] >= 1000 ? TempArr3[0,0] - 1000 : TempArr3[0, 0];


        


    }


    private void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        Vector3 centerpos = transform.position;
        Vector3 size = new Vector3(BinggoSize * 2f, -BinggoSize * 2f, 1f);
        Gizmos.DrawWireCube(centerpos + (size * 0.5f), size);

    }


    void Update()
    {
        
    }
}
