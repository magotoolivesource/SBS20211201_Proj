using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberClick : MonoBehaviour
{
    public int BinggoVal = -1;
    //public BingoLogic ParentLogic;
    public BinggoManager ParentManager;

    public void SetChangeClick()
    {
        GetComponent<TextMesh>().color = Color.blue;
        string textval = GetComponent<TextMesh>().text;

        //Debug.Log( $"{textval}, {BinggoVal} : Ŭ����");
        //ParentLogic.SetBinggoVal( BinggoVal );
    }
    private void OnMouseDown()
    {
        SetChangeClick();

        ParentManager.SendEventSelectValue(BinggoVal);
    }


    void Start()
    {
        
    }


    void Update()
    {
        
    }
}
